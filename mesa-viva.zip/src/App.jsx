import { useEffect, useState } from "react";
import {
  Armchair,
  ChefHat,
  Utensils,
  Clock3,
  Users,
  ArrowUpRight,
  Plus,
  Minus,
  Check,
  Flame,
  ReceiptText,
  RotateCcw,
  Leaf,
  CircleCheck,
  Search,
  Wallet,
  X,
} from "lucide-react";
import { menu, createDemo } from "./data";
import {
  statusLabels,
  money,
  minutesSince,
  orderTotal,
  tableOrders,
  billTotal,
  canClose,
  advanceOrder,
  closeTable,
} from "./helpers";
import { Badge, Modal } from "./components";

const STORAGE_KEY = "mesa-viva-v1";
const tabs = [
  { id: "tables", label: "Mesas", icon: Armchair },
  { id: "kitchen", label: "Cozinha", icon: ChefHat },
  { id: "menu", label: "Cardápio", icon: Utensils },
  { id: "cash", label: "Caixa", icon: Wallet },
];
function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (
      saved &&
      Array.isArray(saved.tables) &&
      Array.isArray(saved.orders) &&
      Array.isArray(saved.receipts)
    )
      return saved;
  } catch {
    /* Se os dados locais não puderem ser lidos, usamos a demonstração. */
  }
  return createDemo();
}

export default function App() {
  const [state, setState] = useState(loadState);
  const [page, setPage] = useState("tables");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState(null);
  const [modal, setModal] = useState(null);
  const [cart, setCart] = useState({});
  const [category, setCategory] = useState("Todos");
  const [note, setNote] = useState("");
  const [service, setService] = useState(false);
  const [toast, setToast] = useState("");
  const [storageError, setStorageError] = useState(false);
  const [now, setNow] = useState(Date.now());
  // useEffect conecta o estado à persistência e ao relógio.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }, [state]);
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    const sync = (event) => {
      if (event.key === STORAGE_KEY && event.newValue) setState(loadState());
    };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);

  const occupied = state.tables.filter((table) => table.openedAt);
  const active = state.orders.filter((order) =>
    ["waiting", "preparing", "ready"].includes(order.status),
  );
  const ready = active.filter((order) => order.status === "ready");
  const selected = state.tables.find((table) => table.id === selectedId);
  const orders = tableOrders(state, selectedId);
  const subtotal = billTotal(orders);
  const cartItems = menu
    .filter((item) => cart[item.id])
    .map((item) => ({ ...item, quantity: cart[item.id] }));
  const cartTotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );
  const revenue = state.receipts.reduce(
    (sum, receipt) => sum + receipt.subtotal + receipt.service,
    0,
  );

  function openTable(table) {
    setSelectedId(table.id);
    setModal(table.openedAt ? "detail" : "open");
  }
  function changeQuantity(id, amount) {
    setCart((previous) => ({
      ...previous,
      [id]: Math.max(0, (previous[id] || 0) + amount),
    }));
  }
  function newOrder() {
    setCart({});
    setNote("");
    setCategory("Todos");
    setModal("order");
  }
  function sendOrder() {
    if (!cartItems.length) return;
    setState((previous) => {
      if (!previous.tables.find((table) => table.id === selectedId)?.openedAt)
        return previous;
      return {
        ...previous,
        orders: [
          ...previous.orders,
          {
            id: crypto.randomUUID(),
            tableId: selectedId,
            items: cartItems,
            note: note.trim(),
            status: "waiting",
            createdAt: Date.now(),
          },
        ],
      };
    });
    setModal("detail");
    setToast("Pedido enviado para a cozinha!");
  }
  function advance(id) {
    setState((previous) => advanceOrder(previous, id));
    setToast("Status do pedido atualizado.");
  }
  const titles = {
    tables: [
      "Tudo pronto para receber.",
      "Cada mesa, um bom momento. Cuide do salão por aqui.",
    ],
    kitchen: [
      "O próximo sabor começa aqui.",
      "Do pedido à entrega, a equipe trabalha em sintonia.",
    ],
    menu: [
      "Feito para dar água na boca.",
      "Um cardápio enxuto, cheio de favoritos.",
    ],
    cash: [
      "Contas em dia. Salão tranquilo.",
      "Acompanhe as contas fechadas nesta demonstração.",
    ],
  };

  return (
    <div className="min-h-screen">
      <aside className="sidebar">
        <a
          href="#"
          className="brand"
          onClick={(event) => {
            event.preventDefault();
            setPage("tables");
          }}
        >
          <span className="brand-icon">
            <Utensils size={23} />
          </span>
          <span>
            Mesa<span className="font-normal">Viva</span>
            <small>SEU SALÃO EM SINTONIA</small>
          </span>
        </a>
        <p className="eyebrow mt-12 mb-4 px-3">ESPAÇO DE TRABALHO</p>
        <nav className="space-y-2" aria-label="Navegação principal">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setPage(id)}
              className={`nav-item ${page === id ? "active" : ""}`}
              aria-current={page === id ? "page" : undefined}
            >
              <Icon size={20} />
              {label}
              {id === "kitchen" && active.length > 0 && (
                <span className="nav-count">{active.length}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <span className="flex items-center gap-2 font-semibold">
            <Leaf size={18} /> Aprender fazendo
          </span>
          <p className="mt-2 text-xs leading-5 text-stone-500">
            Um pequeno restaurante.
            <br />
            Grandes ideias para sua turma.
          </p>
          <span className="mt-4 inline-block rounded-lg bg-white px-3 py-1 text-xs text-stone-500">
            Versão didática • 1.0
          </span>
        </div>
      </aside>

      <div className="main-shell">
        <header className="topbar">
          <span className="flex items-center gap-2 text-sm text-stone-500">
            <span className="status-dot" /> Restaurante aberto
          </span>
          <div className="flex items-center gap-4">
            <span className="hidden text-xs text-stone-500 sm:block">
              {new Date(now).toLocaleDateString("pt-BR", {
                weekday: "long",
                day: "numeric",
                month: "long",
              })}
            </span>
            <span className="avatar" title="Perfil de demonstração">
              MV
            </span>
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-5 py-7 sm:px-8 lg:px-10 lg:py-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow mb-3">
                MESA VIVA /{" "}
                {tabs.find((tab) => tab.id === page).label.toUpperCase()}
              </p>
              <h1 className="headline">{titles[page][0]}</h1>
              <p className="mt-2 max-w-lg text-sm leading-6 text-stone-500">
                {titles[page][1]}
              </p>
            </div>
            <button className="text-button" onClick={() => setModal("reset")}>
              <RotateCcw size={15} /> Reiniciar demo
            </button>
          </div>
          {storageError && (
            <p
              role="alert"
              className="mt-4 rounded-xl bg-amber-100 p-3 text-sm"
            >
              Não foi possível salvar neste navegador. Seus dados estão
              disponíveis apenas enquanto esta página estiver aberta.
            </p>
          )}

          {page === "tables" && (
            <>
              <section
                className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4"
                aria-label="Resumo do salão"
              >
                {[
                  [
                    "Mesas ocupadas",
                    `${occupied.length}/${state.tables.length}`,
                    Users,
                    "green",
                  ],
                  [
                    "Mesas livres",
                    state.tables.length - occupied.length,
                    Armchair,
                    "neutral",
                  ],
                  ["Pedidos em andamento", active.length, Flame, "orange"],
                  ["Prontos para servir", ready.length, CircleCheck, "green"],
                ].map(([label, value, Icon, color]) => (
                  <div className="stat-card" key={label}>
                    <span className={`stat-icon ${color}`}>
                      <Icon size={20} />
                    </span>
                    <div className="mt-4 text-3xl font-bold tracking-tight">
                      {value}
                    </div>
                    <p className="mt-1 text-xs text-stone-500">{label}</p>
                  </div>
                ))}
              </section>
              {ready.length > 0 && (
                <button
                  className="ready-banner"
                  onClick={() => {
                    setPage("kitchen");
                  }}
                >
                  <span className="flex items-center gap-3">
                    <span className="rounded-full bg-white/70 p-2">
                      <ChefHat size={19} />
                    </span>
                    <span>
                      <strong>
                        {ready.length} pedido{ready.length > 1 ? "s" : ""}{" "}
                        pronto{ready.length > 1 ? "s" : ""} para sair!
                      </strong>
                      <small className="mt-1 block font-normal">
                        A cozinha caprichou. Hora de servir.
                      </small>
                    </span>
                  </span>
                  <ArrowUpRight size={20} />
                </button>
              )}
              <section className="mt-8">
                <div className="mb-5 flex flex-wrap items-center justify-between gap-4">
                  <h2 className="text-xl font-bold">
                    Seu salão{" "}
                    <span className="ml-2 text-sm font-normal text-stone-400">
                      12 mesas
                    </span>
                  </h2>
                  <label className="search-box">
                    <Search size={17} />
                    <input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder="Buscar mesa ou cliente"
                      aria-label="Buscar mesa ou cliente"
                    />
                  </label>
                </div>
                <div className="mb-5 flex flex-wrap gap-2">
                  {[
                    ["all", "Todas"],
                    ["occupied", "Ocupadas"],
                    ["free", "Livres"],
                  ].map(([id, label]) => (
                    <button
                      key={id}
                      className={`filter-chip ${filter === id ? "selected" : ""}`}
                      onClick={() => setFilter(id)}
                      aria-pressed={filter === id}
                    >
                      {label}
                    </button>
                  ))}
                  <span className="ml-auto hidden items-center gap-4 text-xs text-stone-500 sm:flex">
                    <span>
                      <i className="legend-dot bg-emerald-600" /> Ocupada
                    </span>
                    <span>
                      <i className="legend-dot bg-stone-300" /> Livre
                    </span>
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
                  {state.tables
                    .filter(
                      (table) =>
                        (filter === "all" ||
                          (filter === "occupied"
                            ? table.openedAt
                            : !table.openedAt)) &&
                        `${table.id} ${table.customer}`
                          .toLowerCase()
                          .includes(search.toLowerCase()),
                    )
                    .map((table) => {
                      const ownOrders = tableOrders(state, table.id).filter(
                        (order) => order.status !== "cancelled",
                      );
                      const last = ownOrders.at(-1);
                      const hasReady = ownOrders.some(
                        (order) => order.status === "ready",
                      );
                      const elapsed = last
                        ? minutesSince(last.createdAt, now)
                        : null;
                      return (
                        <button
                          key={table.id}
                          className={`table-card ${table.openedAt ? "occupied" : "free"}`}
                          onClick={() => openTable(table)}
                          aria-label={`Mesa ${table.id}, ${table.openedAt ? `ocupada por ${table.customer}` : "livre"}`}
                        >
                          <div className="flex items-center justify-between gap-1">
                            <span className="table-icon">
                              <Armchair size={21} />
                            </span>
                            <Badge
                              status={table.openedAt ? "occupied" : "free"}
                            >
                              {table.openedAt ? "Ocupada" : "Livre"}
                            </Badge>
                          </div>
                          <h3 className="mt-5 text-xl font-bold">
                            Mesa {String(table.id).padStart(2, "0")}
                          </h3>
                          <p className="mt-1 truncate text-xs text-stone-500">
                            {table.openedAt
                              ? table.customer
                              : "À espera de bons momentos"}
                          </p>
                          {table.openedAt ? (
                            <>
                              <div className="my-4 flex items-center justify-between gap-1 border-y border-stone-100 py-3">
                                <span className="flex items-center gap-1 text-xs text-stone-500">
                                  <Users size={13} /> {table.guests}
                                </span>
                                <strong className="text-sm">
                                  {money(billTotal(ownOrders))}
                                </strong>
                              </div>
                              <p
                                className={`flex items-center gap-1.5 text-xs ${hasReady ? "text-emerald-700" : elapsed >= 15 ? "text-amber-700" : "text-stone-500"}`}
                              >
                                <Clock3 size={13} />
                                {hasReady
                                  ? "Pedido pronto!"
                                  : last
                                    ? `Último pedido há ${elapsed} min`
                                    : "Ainda sem pedidos"}
                              </p>
                            </>
                          ) : (
                            <div className="mt-5 flex items-center gap-1.5 border-t border-dashed border-stone-200 pt-4 text-xs font-semibold text-stone-400">
                              <Plus size={14} /> Abrir mesa
                            </div>
                          )}
                        </button>
                      );
                    })}
                </div>
                {!state.tables.some(
                  (table) =>
                    (filter === "all" ||
                      (filter === "occupied"
                        ? table.openedAt
                        : !table.openedAt)) &&
                    `${table.id} ${table.customer}`
                      .toLowerCase()
                      .includes(search.toLowerCase()),
                ) && (
                  <p className="empty">
                    Nenhuma mesa encontrada. Tente outro nome ou número.
                  </p>
                )}
              </section>
            </>
          )}

          {page === "kitchen" && (
            <section className="mt-8 grid gap-5 lg:grid-cols-3">
              {["waiting", "preparing", "ready"].map((status) => (
                <div key={status} className="kitchen-column">
                  <h2 className="mb-4 flex items-center justify-between font-bold">
                    <span className="flex items-center gap-2">
                      <span
                        className={`legend-dot ${status === "preparing" ? "bg-orange-400" : status === "ready" ? "bg-emerald-600" : "bg-stone-400"}`}
                      />
                      {statusLabels[status]}
                    </span>
                    <span className="text-sm text-stone-400">
                      {active.filter((order) => order.status === status).length}
                    </span>
                  </h2>
                  {active
                    .filter((order) => order.status === status)
                    .sort((a, b) => a.createdAt - b.createdAt)
                    .map((order) => (
                      <article key={order.id} className="order-card">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-bold">
                            Mesa {String(order.tableId).padStart(2, "0")}
                          </h3>
                          <span className="flex items-center gap-1 text-xs text-stone-500">
                            <Clock3 size={13} />
                            {minutesSince(order.createdAt, now)} min
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-stone-400">
                          {
                            state.tables.find(
                              (table) => table.id === order.tableId,
                            )?.customer
                          }
                        </p>
                        <ul className="my-5 space-y-3">
                          {order.items.map((item) => (
                            <li key={item.id} className="flex gap-2 text-sm">
                              <strong className="text-emerald-800">
                                {item.quantity}×
                              </strong>
                              {item.name}
                            </li>
                          ))}
                        </ul>
                        {order.note && (
                          <p className="mb-4 rounded-lg bg-amber-50 p-3 text-xs leading-5 text-amber-900">
                            Observação: {order.note}
                          </p>
                        )}
                        <button
                          className="button w-full"
                          onClick={() => advance(order.id)}
                        >
                          {status === "waiting" ? (
                            <Flame size={16} />
                          ) : (
                            <Check size={16} />
                          )}
                          {status === "waiting"
                            ? "Começar preparo"
                            : status === "preparing"
                              ? "Marcar como pronto"
                              : "Confirmar entrega"}
                        </button>
                      </article>
                    ))}
                  {!active.some((order) => order.status === status) && (
                    <div className="empty border border-dashed border-stone-200">
                      <ChefHat
                        size={28}
                        className="mx-auto mb-3 text-stone-300"
                      />
                      Nenhum pedido por aqui.
                    </div>
                  )}
                </div>
              ))}
            </section>
          )}

          {page === "menu" && (
            <>
              <div className="my-6 flex flex-wrap gap-2">
                {["Todos", "Pratos", "Bebidas", "Sobremesas"].map((value) => (
                  <button
                    key={value}
                    className={`filter-chip ${category === value ? "selected" : ""}`}
                    onClick={() => setCategory(value)}
                    aria-pressed={category === value}
                  >
                    {value}
                  </button>
                ))}
              </div>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {menu
                  .filter(
                    (item) =>
                      category === "Todos" || item.category === category,
                  )
                  .map((item) => (
                    <article className="menu-card" key={item.id}>
                      <div className="food-art" aria-hidden="true">
                        {item.emoji}
                      </div>
                      <div className="p-5">
                        <p className="eyebrow">{item.category}</p>
                        <h2 className="mt-2 text-lg font-bold">{item.name}</h2>
                        <p className="mt-1 text-sm text-stone-500">
                          {item.description}
                        </p>
                        <strong className="mt-4 block text-emerald-800">
                          {money(item.price)}
                        </strong>
                      </div>
                    </article>
                  ))}
              </div>
              <p className="mt-5 text-sm text-stone-500">
                Para pedir, abra uma mesa na aba Mesas e toque em “Novo pedido”.
              </p>
            </>
          )}

          {page === "cash" && (
            <section className="mt-8">
              <div className="rounded-2xl bg-[#264d3e] p-7 text-white">
                <p className="text-sm text-white/70">
                  Total recebido na demonstração
                </p>
                <h2 className="mt-2 text-4xl font-bold">{money(revenue)}</h2>
                <p className="mt-4 text-xs text-white/60">
                  {state.receipts.length} contas fechadas • inclui taxa de
                  serviço quando selecionada
                </p>
              </div>
              <h2 className="mt-8 mb-4 text-xl font-bold">Contas fechadas</h2>
              {state.receipts.length === 0 ? (
                <div className="empty">
                  <ReceiptText
                    className="mx-auto mb-3 text-stone-300"
                    size={32}
                  />
                  As contas aparecem aqui depois do fechamento de uma mesa.
                </div>
              ) : (
                <div className="space-y-3">
                  {state.receipts.map((receipt) => (
                    <details
                      key={receipt.id}
                      className="rounded-xl border border-stone-200 bg-white p-5"
                    >
                      <summary className="cursor-pointer">
                        <span className="inline-flex w-[calc(100%-1.5rem)] flex-wrap items-center justify-between gap-2">
                          <span>
                            <strong>
                              Mesa {receipt.tableId} · {receipt.customer}
                            </strong>
                            <small className="mt-1 block text-stone-500">
                              {new Date(receipt.closedAt).toLocaleString(
                                "pt-BR",
                              )}{" "}
                              · {receipt.payment}
                            </small>
                          </span>
                          <strong>
                            {money(receipt.subtotal + receipt.service)}
                          </strong>
                        </span>
                      </summary>
                      <div className="mt-4 border-t border-stone-100 pt-4 text-sm">
                        {receipt.orders
                          .filter((order) => order.status !== "cancelled")
                          .flatMap((order) =>
                            order.items.map((item) => (
                              <p
                                className="mb-2 flex justify-between"
                                key={`${order.id}-${item.id}`}
                              >
                                <span>
                                  {item.quantity}× {item.name}
                                </span>
                                <span>{money(item.quantity * item.price)}</span>
                              </p>
                            )),
                          )}
                        <p className="mt-3 text-stone-500">
                          Serviço: {money(receipt.service)}
                        </p>
                      </div>
                    </details>
                  ))}
                </div>
              )}
            </section>
          )}

          <footer className="mt-10 flex flex-wrap items-center justify-between gap-2 border-t border-stone-200 pt-5 text-[11px] text-stone-400">
            <span>Mesa Viva • Feito para aprender, pensado para encantar.</span>
            <span>Demo local · dados neste navegador</span>
          </footer>
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Navegação mobile">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={page === id ? "active" : ""}
            onClick={() => setPage(id)}
            aria-current={page === id ? "page" : undefined}
          >
            <Icon size={21} />
            <span>
              {label}
              {id === "kitchen" && active.length > 0
                ? ` (${active.length})`
                : ""}
            </span>
          </button>
        ))}
      </nav>
      {toast && (
        <div role="status" className="toast">
          <CircleCheck size={18} />
          {toast}
        </div>
      )}

      {modal === "open" && selected && (
        <Modal
          title={`Abrir mesa ${String(selected.id).padStart(2, "0")}`}
          subtitle="Vamos receber bem seus clientes."
          onClose={() => setModal(null)}
        >
          <form
            onSubmit={(event) => {
              event.preventDefault();
              const data = new FormData(event.currentTarget);
              setState((previous) => ({
                ...previous,
                tables: previous.tables.map((table) =>
                  table.id === selectedId && !table.openedAt
                    ? {
                        ...table,
                        customer: data.get("customer").trim() || "Cliente",
                        guests: Number(data.get("guests")),
                        openedAt: Date.now(),
                      }
                    : table,
                ),
              }));
              setModal("detail");
              setToast("Mesa aberta. Pode anotar o primeiro pedido!");
            }}
          >
            <label className="field-label">
              Nome do cliente
              <input
                name="customer"
                placeholder="Ex.: Ana e família"
                maxLength={40}
                required
                autoFocus
              />
            </label>
            <label className="field-label mt-4">
              Número de pessoas
              <input
                name="guests"
                type="number"
                min="1"
                max="20"
                defaultValue="2"
                required
              />
            </label>
            <button className="button mt-6 w-full" type="submit">
              <Plus size={17} /> Abrir mesa
            </button>
          </form>
        </Modal>
      )}

      {modal === "detail" && selected?.openedAt && (
        <Modal
          title={`Mesa ${String(selected.id).padStart(2, "0")}`}
          subtitle={`${selected.customer} · ${selected.guests} pessoas · aberta há ${minutesSince(selected.openedAt, now)} min`}
          onClose={() => setModal(null)}
        >
          <div className="mb-5 flex items-center justify-between rounded-xl bg-stone-50 p-4">
            <span className="text-sm text-stone-500">Consumo da mesa</span>
            <strong className="text-2xl">{money(subtotal)}</strong>
          </div>
          <button className="button w-full" onClick={newOrder}>
            <Plus size={17} /> Novo pedido
          </button>
          <h3 className="mt-6 mb-4 font-bold">Pedidos da mesa</h3>
          {orders.length === 0 && (
            <p className="empty">
              A mesa está aberta. Que tal o primeiro pedido?
            </p>
          )}
          <div className="space-y-3">
            {[...orders].reverse().map((order) => (
              <article
                key={order.id}
                className="rounded-xl border border-stone-200 p-4"
              >
                <div className="flex items-center justify-between gap-2">
                  <Badge status={order.status}>
                    {statusLabels[order.status]}
                  </Badge>
                  <span className="text-xs text-stone-400">
                    há {minutesSince(order.createdAt, now)} min
                  </span>
                </div>
                <ul className="my-3 space-y-1 text-sm">
                  {order.items.map((item) => (
                    <li key={item.id} className="flex justify-between gap-2">
                      <span>
                        {item.quantity}× {item.name}
                      </span>
                      <span>{money(item.price * item.quantity)}</span>
                    </li>
                  ))}
                </ul>
                {order.note && (
                  <p className="mb-3 text-xs text-stone-500">
                    Obs.: {order.note}
                  </p>
                )}
                <div className="flex items-center justify-between">
                  <strong className="text-sm">
                    {money(orderTotal(order))}
                  </strong>
                  {order.status === "waiting" && (
                    <button
                      className="text-xs text-red-700"
                      onClick={() => {
                        setState((previous) => ({
                          ...previous,
                          orders: previous.orders.map((item) =>
                            item.id === order.id && item.status === "waiting"
                              ? { ...item, status: "cancelled" }
                              : item,
                          ),
                        }));
                        setToast("Pedido cancelado.");
                      }}
                    >
                      Cancelar pedido
                    </button>
                  )}
                  {order.status === "ready" && (
                    <button
                      className="text-button"
                      onClick={() => advance(order.id)}
                    >
                      <Check size={14} /> Entregar
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
          <button
            className="button secondary mt-6 w-full"
            disabled={!canClose(orders)}
            onClick={() => {
              setService(false);
              setModal("bill");
            }}
          >
            <ReceiptText size={17} /> Fechar conta
          </button>
          {!canClose(orders) && (
            <p className="mt-2 text-center text-xs text-stone-500">
              Entregue todos os pedidos antes de fechar a conta.
            </p>
          )}
        </Modal>
      )}

      {modal === "order" && selected?.openedAt && (
        <Modal
          title="Novo pedido"
          subtitle={`Mesa ${selected.id} · ${selected.customer}`}
          onClose={() => setModal("detail")}
        >
          <div className="mb-4 flex flex-wrap gap-2">
            {["Todos", "Pratos", "Bebidas", "Sobremesas"].map((value) => (
              <button
                key={value}
                className={`filter-chip ${category === value ? "selected" : ""}`}
                onClick={() => setCategory(value)}
                aria-pressed={category === value}
              >
                {value}
              </button>
            ))}
          </div>
          <div className="space-y-3">
            {menu
              .filter(
                (item) => category === "Todos" || item.category === category,
              )
              .map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-3 rounded-xl border border-stone-200 p-3"
                >
                  <span
                    className="rounded-lg bg-stone-50 p-2 text-2xl"
                    aria-hidden="true"
                  >
                    {item.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-semibold">{item.name}</h3>
                    <p className="mt-1 text-xs text-stone-500">
                      {money(item.price)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      className="quantity-button"
                      disabled={!cart[item.id]}
                      onClick={() => changeQuantity(item.id, -1)}
                      aria-label={`Remover um ${item.name}`}
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-4 text-center text-sm">
                      {cart[item.id] || 0}
                    </span>
                    <button
                      className="quantity-button"
                      disabled={cart[item.id] >= 20}
                      onClick={() => changeQuantity(item.id, 1)}
                      aria-label={`Adicionar um ${item.name}`}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              ))}
          </div>
          <label className="field-label mt-5">
            Observações para a cozinha
            <textarea
              placeholder="Ex.: sem cebola, carne bem passada…"
              value={note}
              onChange={(event) => setNote(event.target.value)}
              maxLength={200}
              rows={2}
            />
          </label>
          <div className="mt-5 flex justify-between font-bold">
            <span>Total do pedido</span>
            <span>{money(cartTotal)}</span>
          </div>
          <button
            className="button mt-4 w-full"
            disabled={!cartItems.length}
            onClick={sendOrder}
          >
            <ChefHat size={18} /> Enviar para a cozinha
          </button>
        </Modal>
      )}

      {modal === "bill" && selected?.openedAt && (
        <Modal
          title="Fechar conta"
          subtitle={`Mesa ${selected.id} · ${selected.customer}`}
          onClose={() => setModal("detail")}
        >
          <form
            onSubmit={(event) => {
              event.preventDefault();
              const payment = new FormData(event.currentTarget).get("payment");
              setState((previous) =>
                closeTable(previous, selectedId, service, payment),
              );
              setModal(null);
              setToast("Conta fechada! A mesa está livre novamente.");
            }}
          >
            <div className="space-y-4">
              <p className="flex justify-between text-sm">
                <span>Consumo</span>
                <strong>{money(subtotal)}</strong>
              </p>
              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl bg-stone-50 p-4 text-sm">
                <span className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={service}
                    onChange={(event) => setService(event.target.checked)}
                  />{" "}
                  Adicionar serviço (10%)
                </span>
                <strong>{money(Math.round(subtotal * 0.1))}</strong>
              </label>
              <p className="flex justify-between border-t border-stone-100 pt-4 text-xl font-bold">
                <span>Total a pagar</span>
                <span>
                  {money(subtotal + (service ? Math.round(subtotal * 0.1) : 0))}
                </span>
              </p>
              <label className="field-label">
                Forma de pagamento
                <select name="payment">
                  <option>Pix</option>
                  <option>Cartão</option>
                  <option>Dinheiro</option>
                </select>
              </label>
            </div>
            <button
              className="button mt-6 w-full"
              disabled={!canClose(orders)}
              type="submit"
            >
              <Check size={18} /> Confirmar recebimento e liberar mesa
            </button>
            <p className="mt-3 text-center text-xs text-stone-500">
              Registro de demonstração. Nenhum pagamento é processado.
            </p>
          </form>
        </Modal>
      )}

      {modal === "reset" && (
        <Modal
          title="Recomeçar a demonstração?"
          subtitle="Ideal para iniciar uma nova aula."
          onClose={() => setModal(null)}
        >
          <p className="text-sm leading-6 text-stone-600">
            As mesas, os pedidos e as contas salvas serão substituídos pelos
            exemplos iniciais.
          </p>
          <div className="mt-6 flex gap-3">
            <button
              className="button secondary flex-1"
              onClick={() => setModal(null)}
            >
              <X size={16} /> Voltar
            </button>
            <button
              className="button flex-1"
              onClick={() => {
                setState(createDemo());
                setModal(null);
                setSelectedId(null);
                setToast("Demonstração reiniciada.");
              }}
            >
              <RotateCcw size={16} /> Reiniciar
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

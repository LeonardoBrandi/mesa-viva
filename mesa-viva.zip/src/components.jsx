import { useEffect, useRef } from "react";
import { X } from "lucide-react";

export function Badge({ status, children }) {
  return <span className={`badge badge-${status}`}>{children}</span>;
}

export function Modal({ title, subtitle, children, onClose }) {
  const dialog = useRef(null);
  useEffect(() => {
    dialog.current.showModal();
    return () => dialog.current?.close();
  }, []);
  return (
    <dialog
      ref={dialog}
      className="modal"
      onCancel={onClose}
      onClick={(event) => {
        if (event.target === dialog.current) onClose();
      }}
      aria-labelledby="modal-title"
    >
      <header className="flex items-start justify-between gap-4 border-b border-stone-100 p-6">
        <div>
          <p className="eyebrow">ATENDIMENTO</p>
          <h2 id="modal-title" className="text-2xl font-bold">
            {title}
          </h2>
          {subtitle && (
            <p className="mt-1 text-sm text-stone-500">{subtitle}</p>
          )}
        </div>
        <button
          className="icon-button"
          onClick={onClose}
          aria-label="Fechar janela"
        >
          <X size={20} />
        </button>
      </header>
      <div className="p-6">{children}</div>
    </dialog>
  );
}

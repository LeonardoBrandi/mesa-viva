export const statusLabels = {
  waiting: "Na fila",
  preparing: "Preparando",
  ready: "Pronto",
  delivered: "Entregue",
  cancelled: "Cancelado",
};
export const money = (value) =>
  (value / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const minutesSince = (time, now) =>
  Math.max(0, Math.floor((now - time) / 60000));
export const orderTotal = (order) =>
  order.items.reduce((total, item) => total + item.price * item.quantity, 0);
export const tableOrders = (state, tableId) =>
  state.orders.filter((order) => order.tableId === tableId);
export const billTotal = (orders) =>
  orders
    .filter((order) => order.status !== "cancelled")
    .reduce((total, order) => total + orderTotal(order), 0);
export const canClose = (orders) =>
  orders.every((order) => ["delivered", "cancelled"].includes(order.status));

// Uma única sequência evita pular etapas entre salão e cozinha.
export function advanceOrder(state, id) {
  const next = { waiting: "preparing", preparing: "ready", ready: "delivered" };
  return {
    ...state,
    orders: state.orders.map((order) =>
      order.id === id && next[order.status]
        ? { ...order, status: next[order.status] }
        : order,
    ),
  };
}

export function closeTable(state, tableId, service, payment) {
  const table = state.tables.find((table) => table.id === tableId);
  const orders = tableOrders(state, tableId);
  if (!table?.openedAt || !canClose(orders)) return state;
  const subtotal = billTotal(orders);
  const receipt = {
    id: crypto.randomUUID(),
    tableId,
    customer: table.customer,
    closedAt: Date.now(),
    subtotal,
    service: service ? Math.round(subtotal * 0.1) : 0,
    payment,
    orders,
  };
  return {
    ...state,
    tables: state.tables.map((item) =>
      item.id === tableId
        ? { ...item, customer: "", guests: 0, openedAt: null }
        : item,
    ),
    orders: state.orders.filter((order) => order.tableId !== tableId),
    receipts: [receipt, ...state.receipts],
  };
}

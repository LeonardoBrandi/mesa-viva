// Valores em centavos evitam erros de arredondamento com dinheiro.
export const menu = [
  {
    id: 1,
    name: "Burger da casa",
    description: "Pão brioche, carne e cheddar",
    price: 3200,
    category: "Pratos",
    emoji: "🍔",
  },
  {
    id: 2,
    name: "Pizza margherita",
    description: "Mussarela, tomate e manjericão",
    price: 4800,
    category: "Pratos",
    emoji: "🍕",
  },
  {
    id: 3,
    name: "Bowl do jardim",
    description: "Folhas, grãos e legumes frescos",
    price: 2800,
    category: "Pratos",
    emoji: "🥗",
  },
  {
    id: 4,
    name: "Batata crocante",
    description: "Porção com molho especial",
    price: 2200,
    category: "Pratos",
    emoji: "🍟",
  },
  {
    id: 5,
    name: "Limonada fresca",
    description: "Limão, gelo e um toque de hortelã",
    price: 1200,
    category: "Bebidas",
    emoji: "🍋",
  },
  {
    id: 6,
    name: "Suco de laranja",
    description: "Natural, feito na hora",
    price: 1000,
    category: "Bebidas",
    emoji: "🍊",
  },
  {
    id: 7,
    name: "Água mineral",
    description: "Garrafa de 500 ml",
    price: 600,
    category: "Bebidas",
    emoji: "💧",
  },
  {
    id: 8,
    name: "Brownie quentinho",
    description: "Chocolate com sorvete de baunilha",
    price: 1800,
    category: "Sobremesas",
    emoji: "🍫",
  },
];

export function createDemo() {
  const now = Date.now();
  const tables = Array.from({ length: 12 }, (_, index) => ({
    id: index + 1,
    customer: "",
    guests: 0,
    openedAt: null,
  }));
  for (const [id, customer, guests, minutes] of [
    [2, "Camila", 2, 34],
    [4, "João e amigos", 4, 48],
    [7, "Marina", 3, 18],
    [9, "Rafael", 2, 25],
  ]) {
    tables[id - 1] = { id, customer, guests, openedAt: now - minutes * 60000 };
  }
  const order = (id, tableId, status, minutes, products, note = "") => ({
    id,
    tableId,
    status,
    createdAt: now - minutes * 60000,
    note,
    items: products.map(([productId, quantity]) => ({
      ...menu.find((item) => item.id === productId),
      quantity,
    })),
  });
  return {
    tables,
    orders: [
      order("demo-1", 2, "delivered", 30, [
        [1, 2],
        [5, 2],
      ]),
      order(
        "demo-2",
        4,
        "preparing",
        14,
        [
          [2, 2],
          [6, 4],
        ],
        "Uma pizza sem manjericão.",
      ),
      order(
        "demo-3",
        7,
        "waiting",
        6,
        [
          [3, 2],
          [1, 1],
          [7, 3],
        ],
        "Burger bem passado.",
      ),
      order("demo-4", 9, "ready", 10, [
        [4, 1],
        [5, 2],
      ]),
    ],
    receipts: [],
  };
}

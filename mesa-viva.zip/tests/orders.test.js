import test from "node:test";
import assert from "node:assert/strict";
import {
  advanceOrder,
  billTotal,
  canClose,
  closeTable,
  minutesSince,
} from "../src/helpers.js";

function fixture(status = "waiting") {
  return {
    tables: [{ id: 1, customer: "Ana", guests: 2, openedAt: 100 }],
    orders: [
      {
        id: "order-1",
        tableId: 1,
        status,
        items: [{ id: 1, name: "Prato", price: 1235, quantity: 3 }],
        createdAt: 100,
      },
    ],
    receipts: [],
  };
}

test("pedido percorre todas as etapas sem modificar o estado anterior", () => {
  const initial = fixture();
  let state = advanceOrder(initial, "order-1");
  assert.equal(state.orders[0].status, "preparing");
  state = advanceOrder(state, "order-1");
  assert.equal(state.orders[0].status, "ready");
  state = advanceOrder(state, "order-1");
  assert.equal(state.orders[0].status, "delivered");
  assert.equal(advanceOrder(state, "order-1").orders[0].status, "delivered");
  assert.equal(initial.orders[0].status, "waiting");
});
test("cancelamento não entra no consumo nem bloqueia o fechamento", () => {
  assert.equal(billTotal(fixture("cancelled").orders), 0);
  assert.equal(canClose(fixture("cancelled").orders), true);
  assert.equal(
    advanceOrder(fixture("cancelled"), "order-1").orders[0].status,
    "cancelled",
  );
});
test("conta não fecha com pedidos na fila, preparando ou prontos", () => {
  for (const status of ["waiting", "preparing", "ready"]) {
    const state = fixture(status);
    assert.equal(canClose(state.orders), false);
    assert.equal(closeTable(state, 1, true, "Pix"), state);
  }
});
test("fechamento calcula serviço em centavos, guarda recibo e libera mesa", () => {
  const state = closeTable(fixture("delivered"), 1, true, "Pix");
  assert.equal(state.receipts[0].subtotal, 3705);
  assert.equal(state.receipts[0].service, 371);
  assert.equal(state.receipts[0].payment, "Pix");
  assert.equal(state.receipts[0].orders.length, 1);
  assert.equal(state.tables[0].openedAt, null);
  assert.equal(state.orders.length, 0);
  assert.equal(closeTable(state, 1, true, "Pix"), state);
});
test("sem serviço, o total permanece igual ao consumo", () => {
  assert.equal(
    closeTable(fixture("delivered"), 1, false, "Dinheiro").receipts[0].service,
    0,
  );
});
test("tempo é inteiro e não fica negativo", () => {
  assert.equal(minutesSince(0, 125000), 2);
  assert.equal(minutesSince(10000, 0), 0);
});
